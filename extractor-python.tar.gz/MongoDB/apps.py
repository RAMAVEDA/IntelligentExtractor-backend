from django.apps import AppConfig


class MongodbConfig(AppConfig):
    name = 'MongoDB'
